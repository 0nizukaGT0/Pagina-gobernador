----NOTAS---
1.-Para la tarea 6 los archivos javascript importantes son los que lleven la palabra AJAX en su nombre 
2.-Los de mas archivos javascript son de antiguaas tareas
3.-Los archivos JavaScript con la palabra "prueba" son como los javascript core de los javascript "ajax"
4.-en codigo/funcines-utiles.js estan la amyoria de la funcies que use , como se reptian tanto lo pase ahi