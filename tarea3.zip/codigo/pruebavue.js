//URL
let congress = '113'; //102-115
let chamber = 'senate';
const url = `https://api.propublica.org/congress/v1/${congress}/${chamber}/members.json`;
const apiKey = 'cf9RM1umZPJ6MoCiiFrwPRDF7NjccEPqPMfiTEfv';
let header = {
  method: 'GET',
  headers: {
    'X-API-Key': apiKey
  }
};
var optionsState = new Vue({
  el: '#select_State',
  data: {
    state: []
  }
});
let dato = [];
var app = new Vue({
  el: '#senate-data',
  data: {
    senators: []
  }
});
function filtrarEstate(miembros) {
  let miembrosFiltrados = [];
  for (let i = 0; i < miembros.length; i++) {
    if (miembros[i].state === document.getElementsByName('state')[0].value) {
      miembrosFiltrados.push(miembros[i]);
    }

  }
  return miembrosFiltrados;
}

function filtrarParty(miembros) {
  let miembrosFiltrados = [];
  //este filtro de bera fitrar los resultdos en realcion a los 3 checkboxes ,
  for (let i = 0; i < miembros.length; i++) {

    if (miembros[i].party === document.getElementsByName('party')[0].value && document.getElementsByName('party')[0].checked) {
      miembrosFiltrados.push(miembros[i]);
    }
    if (miembros[i].party === document.getElementsByName('party')[1].value && document.getElementsByName('party')[1].checked) {
      miembrosFiltrados.push(miembros[i]);
    }
    if (miembros[i].party === document.getElementsByName('party')[2].value && document.getElementsByName('party')[2].checked) {
      miembrosFiltrados.push(miembros[i]);
    }
  }
  return miembrosFiltrados;
}

function mostrarTabla(miembros) {
app.senators=miembros;
}

function aplicarFiltros(miembros) {
  if ((document.querySelectorAll('input[name=party]:checked').length !== 0 || document.getElementsByName('state')[0].value !== "all")) {
    if (document.getElementsByName('state')[0].value !== "all") {
      miembros = filtrarEstate(miembros);
    }
    if (document.querySelectorAll('input[name=party]:checked').length !== 0) {
      miembros = filtrarParty(miembros);
    }
    return miembros;
  } else {
    return miembros;
  }
}

function cargarDatos(array) {
  let miembros = array.results[0].members;
  let miembrosfiltrados = aplicarFiltros(miembros);
  console.log('hola');
  mostrarTabla(miembrosfiltrados);
  return array;
}

function loadData(url, header) {
  let datos = fetch(url, header)
    .then((result) => result.json())
    // .then(result => {
    //   optionsState.state = result.results[0].members;
    //   return result;
    // })
    // datos.then(result => cargarDatos(result))
    .catch(error => console.error('Miguel el error es el siguiente: ', error));
  return datos;
}
let datos = loadData(url, header);
datos.then(result => {
  optionsState.state = result.results[0].members;
  return result;
});
console.log(datos);
datos.then(result => cargarDatos(result));
